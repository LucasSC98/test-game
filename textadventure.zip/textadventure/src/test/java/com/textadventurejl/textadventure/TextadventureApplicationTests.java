package com.textadventurejl.textadventure;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TextadventureApplicationTests {

	@Test
	void contextLoads() {
	}

}
