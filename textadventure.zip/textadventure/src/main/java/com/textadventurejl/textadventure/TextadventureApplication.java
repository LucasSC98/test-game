package com.textadventurejl.textadventure;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TextadventureApplication {

	public static void main(String[] args) {
		SpringApplication.run(TextadventureApplication.class, args);
	}

}
